﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceedERP.Core.Domain.printing.PrintingEstimation
{
    public class PrintingEstimationRoles
    {
        public const string PrintingEstimationAdmin = " PrintingEstimation_Admin";
        public const string PrintingEstimationFormUser = " PrintingEstimationForm_User";
    }
}
