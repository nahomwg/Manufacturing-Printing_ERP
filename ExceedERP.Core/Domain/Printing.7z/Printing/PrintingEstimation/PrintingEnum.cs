﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceedERP.Core.Domain.printing.PrintingEstimation
{
    public enum PrintingSteps
    {
        PrePrint,
        Printing,
        Finishing
    }
}
