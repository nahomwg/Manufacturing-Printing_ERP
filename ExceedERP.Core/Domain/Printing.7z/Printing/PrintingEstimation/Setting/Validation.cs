﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceedERP.Core.Domain.printing.PrintingEstimation.Setting
{
   public class Validation
    {
        public bool IsChecked { get; set; }
        public bool IsApproved { get; set; }
    }
}
