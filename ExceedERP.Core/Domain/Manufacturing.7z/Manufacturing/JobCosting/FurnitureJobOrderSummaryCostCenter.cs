﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceedERP.Core.Domain.Manufacturing.JobCosting
{
   public class FurnitureJobOrderSummaryCostCenter
    {
        public int FurnitureJobOrderSummaryCostCenterId { get; set; }
        public int JobId { get; set; }
    }
   
}
